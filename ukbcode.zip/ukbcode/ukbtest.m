[datar,~,~,headr]=y_ReadAll('filtered_func_data_cleans.nii.gz');
[datat,~,~,headt]=y_ReadAll('zstat2s.nii.gz');
size(datar)